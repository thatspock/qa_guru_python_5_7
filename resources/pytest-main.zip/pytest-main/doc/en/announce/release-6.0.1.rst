pytest-6.0.1
=======================================

pytest 6.0.1 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Bruno Oliveira
* Mattreex
* Ran Benita
* hp310780


Happy testing,
The pytest Development Team
