pytest-3.0.3
============

pytest 3.0.3 has just been released to PyPI.

This release fixes some regressions and bugs reported in the last version,
being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The changelog is available at http://doc.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

* Bruno Oliveira
* Florian Bruhin
* Floris Bruynooghe
* Huayi Zhang
* Lev Maximov
* Raquel Alegre
* Ronny Pfannschmidt
* Roy Williams
* Tyler Goodlet
* mbyt

Happy testing,
The pytest Development Team
